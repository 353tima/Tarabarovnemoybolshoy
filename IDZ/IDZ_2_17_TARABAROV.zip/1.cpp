#include <iostream>
#include <cmath>

int main() {
    double a, b, alpha;
    std::cin >> a >> b >> alpha;
    alpha = alpha * 3.14 / 180.0;
    std::cout << (a + b) / 2.0 * (((a - b) / 2.0) * std::tan(alpha));
    return 0;
}