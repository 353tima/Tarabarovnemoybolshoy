#include <iostream>

int main() {
    double a;
    std::cin >> a;
    double a2 = a * a;
    double a5 = a2 * a2 * a;
    double a19 = a5 * a5 * a5 * a2 * a2;
    std::cout << a5 << "\n" << a19;
    return 0;
}