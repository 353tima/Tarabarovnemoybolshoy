#include <iostream>
#include <cmath>

int main() {
    double c, d;
    std::cin >> c >> d;
    double x1 = c - d;
    double x2 = c + d;
    double A = c * x1 * x1 * x1 + d * x2 * x2 - c * d;
    double B = c * x1 * x1 * x1 + d * x2 * x2 - x1;
    double num = std::sin(A);
    num = num * num * num;
    if (num < 0) num = -num;
    double den = std::sqrt(B * B + 3.14);
    double res = num / den + std::tan(B);
    std::cout << res;
    return 0;
}