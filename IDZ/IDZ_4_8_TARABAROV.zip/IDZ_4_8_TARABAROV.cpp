#include <iostream>
#include <cmath>

int main() {
    double b;
    std::cin >> b;

    double a = b;  // a1 = b
    int i = 1;

    while (a <= 0) {
        i++;
        double s = std::sin(i);
        a = (a + 1) / (i - s * s);
    }

    std::cout << i << std::endl;
    return 0;
}