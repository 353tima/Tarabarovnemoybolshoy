#include <iostream>
using namespace std;

int main() {
    long long fact1 = 1;
    for (int i = 1; i <= 10; ++i) {
        fact1 *= i;
    }
    cout << "10! (for): " << fact1 << endl;

    long long fact2 = 1;
    int j = 1;
    while (j <= 10) {
        fact2 *= j;
        j++;
    }
    cout << "10! (while): " << fact2 << endl;

    long long fact3 = 1;
    int k = 1;
    do {
        fact3 *= k;
        k++;
    } while (k <= 10);
    cout << "10! (do-while): " << fact3 << endl;

    return 0;
}