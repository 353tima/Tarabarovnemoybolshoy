#include <iostream>
#include <cmath>
using namespace std;

double nested_sqrt(int n) {
    if (n > 99) return 0;
    if (n == 99) return sqrt(99.0);
    return sqrt(n + nested_sqrt(n + 3));
}

int main() {
    double result = nested_sqrt(3);
    cout << "Результат: " << result << endl;
    return 0;
}