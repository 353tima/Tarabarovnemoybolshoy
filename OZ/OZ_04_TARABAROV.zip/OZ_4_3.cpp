#include <iostream>
#include <cmath>
using namespace std;

int main() {
    double x;
    cout << "Введите x (в радианах): ";
    cin >> x;

    double current = x;
    int steps = 0;

    while (fabs(current) >= 0.0001) {
        current = sin(current);
        steps++;
        if (steps > 1000) {
            cout << "Слишком много итераций — возможно, ошибка." << endl;
            break;
        }
    }

    cout << "Первое значение по модулю < 0.0001: " << current << endl;
    cout << "Количество итераций: " << steps << endl;

    return 0;
}
