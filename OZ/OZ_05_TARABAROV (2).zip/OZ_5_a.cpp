#include <iostream>
using namespace std;

int main() {
    double x, eps;
    cout << "x = ";
    cin >> x;
    cout << "eps = ";
    cin >> eps;

    double sum = 0.0;
    double term = 1.0;
    int n = 0;

    while (true) {
        sum += term;
        double mod_term = term;
        if (mod_term < 0) mod_term = -mod_term;
        if (mod_term < eps) break;

        n++;
        term = term * x / n;
    }

    cout << "e^x ≈ " << sum << endl;
    return 0;
}