#include <iostream>
using namespace std;

int main() {
    double x, eps;
    cout << "x (|x| < 1) = ";
    cin >> x;
    cout << "eps = ";
    cin >> eps;

    double sum = 0.0;
    double term = x;
    int n = 1;

    while (true) {
        sum += term;
        double mod_term = term;
        if (mod_term < 0) mod_term = -mod_term;
        if (mod_term < eps) break;

        n++;
        term = term * (-x) * (n - 1) / n;
    }

    cout << "ln(1+x) ≈ " << sum << endl;
    return 0;
}